<?php
// seven deadly sins
return [
   'two' => 'gluttony',
   'tre' => 'greed',
   'six' => 'envy',
   'sev' => 'pride',
];
