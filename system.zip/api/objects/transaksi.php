<?php
	class Transaksi{
		private $conn;

		private $IDUser;
		private $JenisPembayaran;
		private $TotalHarga;
		private $id;
		public function __construct($db){
			$this->conn = $db;
		}
		public function insertTransaksi($IDUser , $JenisPembayaran, $TotalHarga){
			$query = "SELECT COUNT(*)+1 FROM transaksi";
			$stm = $this->conn->prepare($query);
			$stm->execute();
			$ID = $stm->fetchColumn();
			$IDUser = (int) $IDUser;
			$ID = (int) $ID;
			$this->id = $ID;
			$TotalHarga = (int) $TotalHarga;
			$query = "INSERT INTO transaksi(waktu,ID,ID_user,jenis_pembayaran,total_harga,status) values(NOW(),'$ID','$IDUser','$JenisPembayaran','$TotalHarga',0)";
			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			return $stmt;
		}
		public function insertDetailTransaksi($IDTransaksi,$IDBarang,$Jumlah){
			$IDTransaksi = (int) $IDTransaksi;
			$IDBarang = (int) $IDBarang;
			$Jumlah = (int) $Jumlah;
			$query = "INSERT INTO transaksi_detail VALUES('$IDTransaksi','$IDBarang','$Jumlah')";
			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			return $stmt;
		}
		public function getID(){
			return $this->id;
		}
		public function getAllTransaksi($id){
			$query = "SELECT waktu,ID,jenis_pembayaran,total_harga,status FROM transaksi WHERE ID_user = '$id'";
			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			return $stmt;
		}
	}

?>
